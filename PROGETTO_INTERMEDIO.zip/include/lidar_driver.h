#ifndef LIDAR_DRIVER_H
#define LIDAR_DRIVER_H

#include <iostream>
#include <vector>
#include <array>
#include <cmath>

class LidarDriver
{
    private:
    static constexpr int BUFFER_DIM = 10; // Numero massimo di scansioni memorizzabili
    double private_res; //Variabile che salva il valore di double resolution
    int scan_size; //Lettura per ogni scanzione 
    int back_scan; //Punta alla scanzione piu' recente
    int front_scan; //Punta alla scanzione meno recente 
    int size; //Numero di scansioni nel buffer circolare
    std::array<std::vector<double>, BUFFER_DIM> buffer; //Buffer per memorizzare le scansioni
    
    public:
    LidarDriver(double resolution); // Costruttore
    void new_scan(const std::vector<double>& scan); //Funzione per aggiungere una nuova scansione
    std::vector<double> get_scan(); //Fornisce in output un vector contenemnte la scansione piu' vecchia del sensore e lo rimuove dal buffer
    void clear_buffer(); //Elimina (senza restituirle) tutte le scansioni salvate
    double get_distance(double angle); /*Restituisce la lettura corrispondente ad angle nella scansione 
                                             piu' recente acquisita dal sensore, se non esiste resitituisce la miusra piu' vicina*/
    std::vector<double> get_last(); //Ottieni l'ultima scansione salvata
    bool empty() const {return size == 0;}//Controlla se l'oggetto di tipo LidarDriver e' vuoto
};
std::ostream& operator<<(std::ostream& os, LidarDriver& driver); //stampa a schermo l'ultima scansione salvata (ma non la rimuove dal buffer):

#endif