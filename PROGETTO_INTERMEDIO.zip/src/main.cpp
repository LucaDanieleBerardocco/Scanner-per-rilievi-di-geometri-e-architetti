#include "lidar_driver.h"
#include <iostream>
#include <vector>
#include <cmath>

int main()
{
    LidarDriver lidar1(1); //Creo un oggetto di LidarDriver in cui la risoluzione e' 1
    lidar1.new_scan({1.0, 2.0, 3.0, 4.0, 5.0}); //Riempio la prima scansione
    lidar1.new_scan({6.0, 7.0, 8.0, 9.0, 10.0}); //Riempio la seconda scansione
    
    std::vector<double> x = lidar1.get_scan(); //Fornisce la scansione piu' vecchia
    std::cout << "x: [ ";
    for (int i = 0; i<x.size(); ++i)
    {
        std::cout << x[i] << ", ";
    }
    std::cout << "]\n";
    
    std::cout << lidar1 << "\n"; //Stampo la scansione piu' recente

    std::cout << lidar1.get_distance(3) << "\n"; //Prova del get_distance: essendo che la risoluzione e' di 1, dovrebbe restituire il valore 9.0
    
    lidar1.clear_buffer(); //Vado a liberare l'intero Buffer
    std::cout << lidar1 << "\n";

    
    LidarDriver lidar2(0.5); //Creo un oggetto di LidarDriver in cui la risoluzione e' 0.5
    lidar2.new_scan({1.4, 2.7, 3.2, 4.8, 5.1}); //Riempio la prima scansione
    lidar2.new_scan({6.5, 7.6, 8.8, 9.2, 10.1}); //Riempio la seconda scansione

    std::vector<double> y = lidar2.get_scan(); //Fornisce la scansione piu' vecchia
    std::cout << "y: [ ";
    for (int i = 0; i<y.size(); ++i)
    {
        std::cout << y[i] << " ";
    }
    std::cout << "]\n";
    
    std::cout << lidar2 << "\n"; //Stampo la scansione piu' recente

    std::cout << lidar2.get_distance(2) << "\n"; //Prova del get_distance: essendo che la risoluzione e' di 0.5, dovrebbe restituire il valore 10.1

    lidar2.clear_buffer(); //Vado a liberare l'intero Buffer
    std::cout << lidar2 << "\n";
    
    return 0;
}