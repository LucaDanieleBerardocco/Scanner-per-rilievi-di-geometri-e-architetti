//File .cpp realizzato da Marco 
#include "lidar_driver.h"
#include <iostream>
#include <vector>
#include <cmath>

std::ostream& operator<<(std::ostream& os, LidarDriver& driver)
{
    if(driver.empty())
    {
        std::cout << "Il Buffer e' vuoto. Non e' presente nessuna scansione." << "\n";
        return os;
    }
    
    std::vector<double> temp = driver.get_last();

    std::cout << "Scan piu' recente: [ ";
    for (int i = 0; i<temp.size(); ++i)
    {
        std::cout << temp[i] << ", ";
    }
    std::cout << "]\n";
    return os;
}

std::vector<double> LidarDriver::get_last()
{
    return buffer[back_scan-1];
}