//File .cpp realizzato da Tommaso 
#include "lidar_driver.h"
#include <iostream>
#include <vector>
#include <cmath>

LidarDriver::LidarDriver(double resolution)
{
    private_res = resolution;
    front_scan = 0;
    back_scan = 0; 
    size = 0; //Non ci sono scansioni immesse
    if(resolution <=0 || resolution > 1)
    {
        throw std::invalid_argument("Risoluzione non valida, dev'essere compresa tra 0 e 1");
    }
    scan_size = std::round(180 / resolution) +1; //Numero di letture per ogni scansione

    for (int i = 0; i < BUFFER_DIM; ++i) //Riempio il buffer con BUFFER_DIM vettori vuoti
    {
        buffer[i] = std::vector<double>();
    }
}

void LidarDriver::new_scan(const std::vector<double>& scan)
{
    if(buffer.empty())
    {
        throw std::runtime_error("Il Buffer e' vuoto. Non e' presente nessuna scansione.");
    }

    if (size >= BUFFER_DIM) //Sovrascrivi in caso di buffer pieno la scansione MENO recente 
    {
        front_scan = (front_scan + 1) % BUFFER_DIM; //Incremento l'indice di scansione meno recente
        size--; //Decremento la size perche' in questo caso sto andando a sovrascrivere una scansione gia' fatta
    }

    std::vector<double> resized_scan; //Creo un nuovo vector ausiliario per il salvataggio dei valori
    for(int i = 0; i <  scan_size; ++i)
    {
        if(i < scan.size())
        {
            resized_scan.push_back(scan[i]); //Copio i valori nel nuovo array
        }
        else 
        {
            resized_scan.push_back(0.0); //Riempio con 0 se non ci sono sufficienti valori
        }
    }

    
    buffer[back_scan] = resized_scan; //La scansione piu' recente risulta, ora, quella appena immessa

    back_scan = (back_scan +1) % BUFFER_DIM; //Incremento l'indice di scansione PIU' recente

    size++; //Incremento del numero di scansioni immesse
}

void LidarDriver :: clear_buffer()
{
    for(int i = 0; i<size; ++i) 
    {   
        for(int j = 0; j<scan_size; ++j)
        {
            buffer[i][j] = 0.0;
        }
    }
    
    front_scan = 0;
    back_scan = 0; 
    size = 0;
}