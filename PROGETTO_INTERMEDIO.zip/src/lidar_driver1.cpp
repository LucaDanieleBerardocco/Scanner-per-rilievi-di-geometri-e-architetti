//File .cpp realizzato da Luca Daniele Berardocco
#include "lidar_driver.h"
#include <iostream>
#include <vector>
#include <cmath>

std::vector<double> LidarDriver::get_scan() 
{
    if (buffer.empty()) //Controlla se il buffer e' vuoto o meno
    {
        throw std::runtime_error("Il Buffer e' vuoto. Non e' presente nessuna scansione."); //Se il buffer e' vuoto lancia un'eccezione 
    }
    std::vector<double> oldest_scan = buffer[front_scan]; //Salva la scannerizzazione piu' vecchia in un vector che ritornera' al chiamante 
    size--;
    front_scan = (front_scan + 1) % BUFFER_DIM;
    return oldest_scan;
}

double LidarDriver::get_distance(double angle)
{
    if (buffer.empty()) //Controlla se il buffer e' vuoto o meno
    {
        throw std::runtime_error("Il Buffer e' vuoto. Non e' presente nessuna scansione."); //Se il buffer e' vuoto lancia un'eccezione 
    }
    
    int down = static_cast<int>(std::floor(angle / private_res));
    int up = static_cast<int>(std::ceil(angle / private_res)); 
    
    if (angle < 0 || angle > 180) //Controllo se l'angolo e' fuori dal range, se lo e' lancio l'eccezione
    {
        throw std::invalid_argument("L'angolo inserito e' fuori dal range.");
    }
    
    if(down != up)  //Controllo che i valori dell'angolo non siano uguali
    {
        return (buffer[back_scan-1][down] + buffer[back_scan-1][up]) / 2; //Faccio la media tra i due valori piu' vicini
    }

    return buffer[back_scan-1][down]; //Se i valori sono uguali ritorno proprio quell'angolo
}




